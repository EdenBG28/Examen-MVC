<!DOCTYPE html>
<html lang="en">
<head>
		
	<meta charset="UTF-8">
	<meta name="viewport" content="width=device-width, initial-scale=1.0">
	<link rel="stylesheet" href="../css/myestilou.css">
	<title>Examen practico - MVC</title>
	</body>
<script>
	
	function eliminar(id)
	{
		if(confirm("¿Estas seguro de eliminar el registro?"))
		{
			window.location = "../Controlador/controlador.php?ideliminar=" + id;
		}
	}

	function modificar(id)
	{
		window.location = "../Controlador/controlador.php?idmodificar=" + id;
	}
</script>

</head>
<body>	
<h1>Modelo Vista Controlador</h1>
<div id="div1">
	<div id="div2">
	<form action="../Controlador/controlador.php" id="frminsertar" name="frminsertar" method="post">
		<!-- <label for="">Numero: </label> -->
		<input type="text" id="txtid" name="txtid" value="<?php echo @$buscar_mod[0][0]; ?>" hidden>
		<br>
		<br>
		<label for="">Nombre: </label>
		<input type="text" id="txtnombre" name="txtnombre" value="<?php echo @$buscar_mod[0][1]; ?>" >
		<br>
		<br>
		<label for="">Fecha: </label>
		<input type="date" id="txtfecha" name="txtfecha" value="<?php echo @$buscar_mod[0][2]; ?>" >
		<br>
		<br>
		<input type="submit" id="btninsertar" name="btninsertar" value="<?php if(isset($_GET['idmodificar']))
		{ 
			echo 'Modificar';
		}
		else
		{
			echo 'Insertar';
		}
		 ?>">
	</form>
	<br>
	<form action="../Controlador/controlador.php" id="frmbuscar" name="frmbuscar" method="post">
		<label for="">Buscar: </label>
		<input type="text" id="txtbuscar" name="txtbuscar" >
		<input type="submit" id="btnbuscar" name="btnbuscar" value="Buscar" >
		<br><br>
		<table align="center" width="90%"  border="2">
			<tr>
				<th align="center" height="30">Número</th>
				<th align="center" height="30">Nombre</th>
				<th align="center" height="30">Fecha</th>
				<th colspan="2" align="center"height="30">Accion</th>
			</tr>
			<?php echo @$datos; ?>
		</table>
	</form>
	</div>
</div>
</body>
</html>